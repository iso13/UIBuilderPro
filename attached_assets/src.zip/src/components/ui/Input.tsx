import React from "react";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

const Input: React.FC<InputProps> = ({ className, ...props }) => {
  return (
    <input
      {...props} // ✅ Spreads all valid props, including `min` and `max`
      className={`border border-gray-600 rounded-md px-3 py-2 bg-gray-800 text-white focus:ring focus:ring-blue-500 focus:outline-none ${className}`}
    />
  );
};

export default Input;