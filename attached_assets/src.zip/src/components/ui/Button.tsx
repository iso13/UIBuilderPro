import React from "react";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  onClick?: () => void | Promise<void>; // ✅ Fix the type
}

const Button: React.FC<ButtonProps> = ({ children, onClick, ...props }) => {
  return (
    <button
      className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md w-full transition"
      onClick={onClick} // ✅ Now correctly typed
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;