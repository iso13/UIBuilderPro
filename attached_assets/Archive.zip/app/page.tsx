"use client";
import { useState } from "react";
import axios from "axios";
import Input from "@/components/ui/Input";
import Textarea from "@/components/ui/Textarea";
import Button from "@/components/ui/Button";

export default function FeatureGenerator() {
  const [featureTitle, setFeatureTitle] = useState("");
  const [featureStory, setFeatureStory] = useState("");
  const [scenarioCount, setScenarioCount] = useState(2);
  const [generatedFeature, setGeneratedFeature] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateFeature = async () => {
    setGeneratedFeature(null);
    setError(null);

    if (!featureTitle.trim() || !featureStory.trim()) {
      setError("Feature title and story are required.");
      return;
    }

    try {
      const response = await axios.post("/api/generate-feature", {
        featureTitle,
        featureStory,
        scenarioCount,
      });

      setGeneratedFeature(response.data.feature);
    } catch (error: any) {
      console.error("❌ API Error:", error.response ? error.response.data : error.message);
      setError(error.response ? error.response.data.error : "Failed to generate feature.");
    }
  };

  const handleScenarioCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value); // Parse the string value to an integer

    if (isNaN(value)) {
      setScenarioCount(2); // Default to 2 if not a number
    } else {
      setScenarioCount(Math.max(2, Math.min(10, value))); // Ensure value is between 2 and 10
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h1 className="text-2xl font-bold mb-4">Feature Generator</h1>

      <label className="block text-gray-700 font-medium mb-1">Feature Title</label>
      <Input
        type="text"
        value={featureTitle}
        onChange={(e) => setFeatureTitle(e.target.value)}
        placeholder="Enter feature title"
        className="w-full mb-3"
      />

      <label className="block text-gray-700 font-medium mb-1">Feature Story</label>
      <Textarea
        value={featureStory}
        onChange={(e) => setFeatureStory(e.target.value)}
        placeholder="Enter feature story"
        className="w-full mb-3"
      />

      <label className="block text-gray-700 font-medium mb-1">Number of Scenarios</label>
      <Input
        type="number" // Change type to "number"
        value={scenarioCount}
        onChange={handleScenarioCountChange} // Use the new handler
        className="w-full mb-3"
        min={2} // Set minimum value to 2
        max={10} // Set maximum value to 10
      />

      <Button onClick={handleGenerateFeature} className="w-full bg-blue-500 text-white p-2 rounded-md">
        Generate Feature
      </Button>

      {error && <p className="mt-4 text-red-500">{error}</p>}

      {generatedFeature && (
        <div className="mt-6 p-4 bg-gray-100 rounded-md">
          <h2 className="text-lg font-semibold mb-2">Generated Feature</h2>
          <pre className="whitespace-pre-wrap text-gray-800">{generatedFeature}</pre>
        </div>
      )}
    </div>
  );
}