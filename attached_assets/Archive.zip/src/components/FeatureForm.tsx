import { useState } from "react";

export default function FeatureGenerator() {
  const [featureTitle, setFeatureTitle] = useState("");
  const [scenarioCount, setScenarioCount] = useState("2");
  const [message, setMessage] = useState("");

  const generateFeature = async () => {
    setMessage(""); // Clear previous messages

    const response = await fetch("/generate-feature", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        featureTitle,
        scenarioCount: parseInt(scenarioCount, 10),
      }),
    });

    const data = await response.json();
    if (response.ok) {
      setMessage(`✅ Feature file created successfully: ${data.message}`);
    } else {
      setMessage(`❌ Error: ${data.error}`);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white">
      <div className="w-full max-w-lg bg-gray-800 p-6 rounded-lg shadow-lg">
        <h1 className="text-2xl font-bold text-center mb-4">
          Cucumber Feature Generator
        </h1>

        <label className="block mb-2 text-sm font-medium text-gray-300">
          Feature Title:
        </label>
        <input
          type="text"
          className="w-full p-2 mb-4 rounded bg-gray-700 text-white border border-gray-600 focus:ring-2 focus:ring-blue-400"
          value={featureTitle}
          onChange={(e) => setFeatureTitle(e.target.value)}
          placeholder="Enter feature title"
        />

        <label className="block mb-2 text-sm font-medium text-gray-300">
          Number of Scenarios:
        </label>
        <input
          type="number"
          min="1"
          max="6"
          className="w-full p-2 mb-4 rounded bg-gray-700 text-white border border-gray-600 focus:ring-2 focus:ring-blue-400"
          value={scenarioCount}
          onChange={(e) => setScenarioCount(e.target.value)}
        />

        <button
          onClick={generateFeature}
          className="w-full py-2 mt-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg transition duration-200"
        >
          Generate Feature
        </button>

        {message && (
          <div className="mt-4 p-3 rounded bg-gray-700 border border-gray-600 text-sm">
            {message}
          </div>
        )}
      </div>
    </div>
  );
}